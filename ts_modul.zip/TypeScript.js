function Rng(alsoHatar, felsoHatar) {
    var randomSzam = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
    return randomSzam;
}
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var generaltSzamokTombje = [];
    for (var i = 1; i <= meret; i++) {
        generaltSzamokTombje.push(Rng(alsoHatar, felsoHatar));
    }
    return generaltSzamokTombje;
}
function Duplazo(vizsgaltTomb) {
    var duplazottTomb = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        duplazottTomb.push(vizsgaltTomb[i] * 2);
    }
    return duplazottTomb;
}
function PrimekSzama(vizsgaltTomb) {
    var primekSzama = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var oszto = 0;
        for (var j = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j == 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            primekSzama++;
        }
    }
    return primekSzama;
}
function EgyediElemek(vizsgaltTomb) {
    var EgyediElemekTombje = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var szerepelE = false;
        for (var j = 0; j < EgyediElemek.length; j++) {
            if (vizsgaltTomb[i] == EgyediElemek[j]) {
                szerepelE = true;
            }
        }
        if (szerepelE == true) {
            EgyediElemekTombje.push(vizsgaltTomb[i]);
        }
    }
    return EgyediElemekTombje;
}
