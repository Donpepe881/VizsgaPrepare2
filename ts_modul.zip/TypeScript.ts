function Rng(alsoHatar: number, felsoHatar: number): number {
    let randomSzam: number = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
    return randomSzam;
}

function TombGenerator(meret: number, alsoHatar: number, felsoHatar: number): number[] {
    let generaltSzamokTombje: number[] = [];
    for (let i: number = 1; i <= meret; i++) {
        generaltSzamokTombje.push(Rng(alsoHatar, felsoHatar));
    }
    return generaltSzamokTombje;
}

function Duplazo(vizsgaltTomb: number[]): number[] {
    let duplazottTomb: number[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        duplazottTomb.push(vizsgaltTomb[i] * 2);
    }
    return duplazottTomb;
}

function PrimekSzama(vizsgaltTomb: number[]): number {
    let primekSzama: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let oszto: number = 0;
        for (let j: number = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j == 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            primekSzama++;
        }
    }
    return primekSzama;
}

function EgyediElemek(vizsgaltTomb: number[]): number[] {
    let EgyediElemekTombje: number[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE = false;
        for (let j: number = 0; j < EgyediElemek.length; j++) {
            if (vizsgaltTomb[i] == EgyediElemek[j]) {
                szerepelE = true;
            }
        }
        if (szerepelE == true) {
            EgyediElemekTombje.push(vizsgaltTomb[i]);
        }
    }
    return EgyediElemekTombje;
}