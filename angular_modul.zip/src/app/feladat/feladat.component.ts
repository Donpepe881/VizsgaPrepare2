import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {

  vizsgaltSzam!: number;
  visszaJelzoSzoveg!: string;

  primE(): boolean {
    let oszto: number = 0;
    for (let i: number = 1; i <= this.vizsgaltSzam; i++) {
      if (this.vizsgaltSzam % i == 0) {
        oszto++;
      }
    }
    if (oszto == 2) {
      return true;
    }
    else {
      return false;
    }
  }

  kieertekeloFuggveny(): void {
    if (this.primE()) {
      this.visszaJelzoSzoveg = "prím";
    }
    else {
      this.visszaJelzoSzoveg = "NEM prím";
    }
  }

  visszaJelzoSzovegTomb: string[] = [];

  EredmenyMentes() {
    if (this.primE()) {
      this.visszaJelzoSzovegTomb.push(`Az ${this.vizsgaltSzam} prím`);
    }
    else {
      this.visszaJelzoSzovegTomb.push(`Az ${this.vizsgaltSzam} NEM prím`);
    }
  }


}
